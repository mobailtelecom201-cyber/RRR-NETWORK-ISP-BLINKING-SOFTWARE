RRR NETWORK ISP Billing Demo

Features:
- Dashboard
- Customer List
- Billing Overview
- Modern Dark UI

How to Run:
1. Extract ZIP
2. Open index.html in browser
